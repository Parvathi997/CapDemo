package Stepdefinitions;

import java.util.Map;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import BaseClass.Base;
import PageObjects.HomePage;
import PageObjects.LoginOrRegisterPage;
import PageObjects.LoginPage;
import PageObjects.RegisterPage;
import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Register extends Base {
	WebDriver driver;

	@Before("@Register")
	public void setup() {

		loadProjectDataProperties();
		this.driver = initializeBrowser(prop.getProperty("browser"));

	}

	@After("@Register")
	public void tearDown() {

		driver.quit();

	}

	@Given("^User visit the Yatra Application$")
	public void user_visit_the_yatra_Application() {

		driver.get(prop.getProperty("url"));
	}

	@And("^User hover on MyAccount and click Register$")
	public void user_hover_on_myaccount_and_click_register() {

		HomePage homePage = new HomePage(driver);
		homePage.selectMyAccountMenu();
		homePage.selectRegisterOption();
	}

	@When("^User enter the not registered EmailId as (.+) and click continue$")
	public void userenterthenotregisteredemailidasandclickcontinuebutton(String loginid) throws InterruptedException {
		String loginidcheck = loginid;
		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);

		lr.enterRegisterId(loginid);

	}

	@Then("^User should be redirected to Register page$")
	public void user_should_be_redirected_to_Register_page() throws InterruptedException {

		RegisterPage registerpage = new RegisterPage(driver);
		boolean reg = registerpage.verifyRegisterPage();
		System.out.println("&&&&&&&&&&&&" + reg);
		Assert.assertTrue(reg);
	}

	@When("^User enter all the valid details into the Register Account page fields$")
	public void user_enter_all_the_valid_details_into_the_register_account_page_fields(DataTable table) {
		RegisterPage registerpage = new RegisterPage(driver);
		Map<String, String> datamap = table.asMap(String.class, String.class);
		String randomEmailAddress = null;
		String originalEmail = datamap.get("EMAILID");
		String[] emailParts = originalEmail.split("@");
		randomEmailAddress = emailParts[0] + getTimeStamp() + "@" + emailParts[1];

		// String regEmail=datamap.get("EMAILID");
		String regPhNo = datamap.get("MOBILENUMBER");
		String regCreatePassword = datamap.get("CREATEPASSWORD");
		String regtitle = datamap.get("Title");
		String regfirstName = datamap.get("FirstName");
		String reglastName = datamap.get("LastName");

		// registerpage.getEmailField().sendKeys(randomEmailAddress);
		registerpage.getPhoneNumber().sendKeys(regPhNo);
		registerpage.getpassword().sendKeys(regCreatePassword);
		registerpage.gettitle().sendKeys(regtitle);
		registerpage.getfirstName().sendKeys(regfirstName);
		registerpage.getlastName().sendKeys(reglastName);

	}

	@And("^User click on Create Account button$")
	public void user_click_on_create_account_button() throws InterruptedException {
		RegisterPage registerpage = new RegisterPage(driver);
		Thread.sleep(2000);
		registerpage.clickCreateAccount();
		Thread.sleep(20000);
		registerpage.clickOtpSubmitButton();
	}

	@Then("^User should be taken to Register success page$")
	public void user_should_be_taken_to_register_success_page() throws InterruptedException {
		System.out.println("inside register success page");
		RegisterPage registerpage = new RegisterPage(driver);

		Thread.sleep(55000);
		boolean alreadyreg = registerpage.checkphoneNumberAlresdyRegistered();
		System.out.println("alreadyregistered" + alreadyreg);
		if (alreadyreg) {
			Thread.sleep(20000);
			registerpage.clickcreateNewAccount();
		}
		Thread.sleep(50000);
		boolean reg = registerpage.verifyRegistersuccesPage();
		System.out.println(reg);
		Assert.assertTrue(reg);
	}

	@Then("^User click on Go to Home Page$")
	public void user_click_on_go_to_home_page() throws InterruptedException {
		RegisterPage registerpage = new RegisterPage(driver);
		registerpage.clickgotoHomeScreen();
	}

	@And("^User should redirect to Home Page with diplayed firstname in header section$")
	public void user_should_redirect_to_home_page_with_diplayed_firstname_in_header_section() {
		HomePage homePage = new HomePage(driver);
		boolean val = homePage.verifyCorrectUserName();
		Assert.assertTrue(val);

	}

	// Scenario2
	@When("^User enter the registered EmailId or PhoneNumber as (.+) and click continue$")
	public void user_enter_the_registered_emailid_or_phonenumber_as_and_click_continue(String loginid) {

		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);

		lr.enterinvalidLoginId(loginid);

	}

	@Then("^User should be able to Login$")
	public void user_should_be_able_to_login() {
		LoginPage loginpage = new LoginPage(driver);

		boolean status = loginpage.verifyLoginPage();

		Assert.assertTrue(status);
	}

	// Scenario3
	@When("^User enter invalid EmailId or PhoneNumber as (.+) and click continue$")
	public void user_enter_invalid_emailid_or_phonenumber_as_and_click_continue(String loginid)
			throws InterruptedException {

		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);

		lr.enterinvalidLoginId(loginid);
	}

	@Then("^User should get propere error message$")
	public void user_should_get_propere_error_message() {

		String actualstatus;
		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);
		String errormsg = lr.getErrorMessage();
		if (errormsg.contains("INVALID")) {
			actualstatus = "true";

		} else {
			actualstatus = "false";

		}
		Assert.assertEquals("true", actualstatus);

	}

	// S2

	@When("^User enter the notregistered EmailId as (.+) and click continue button$")
	public void user_enter_the_not_registered_emailid_as_and_click_continue_button(String loginid)
			throws InterruptedException {
		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);

		lr.enterRegisterId(loginid);
	}

	@Then("^User then redirected to Signup page$")
	public void user_should_be_redirected_to_signup_page() throws InterruptedException {
		RegisterPage registerpage = new RegisterPage(driver);
		boolean reg = registerpage.verifyRegisterPage();
		System.out.println("&&&&&&&&&&&&" + reg);
		Assert.assertTrue(reg);
	}

	@When("^User enter below details into the Register Account page fields$")
	public void user_enter_below_details_into_the_register_account_page_fields(DataTable table) {
		RegisterPage registerpage = new RegisterPage(driver);
		Map<String, String> datamap = table.asMap(String.class, String.class);
		String randomEmailAddress = null;
		String originalEmail = datamap.get("EMAILID");
		String[] emailParts = originalEmail.split("@");
		randomEmailAddress = emailParts[0] + getTimeStamp() + "@" + emailParts[1];

		// String regEmail=datamap.get("EMAILID");
		String regPhNo = datamap.get("MOBILENUMBER");
		String regCreatePassword = datamap.get("CREATEPASSWORD");
		String regtitle = datamap.get("Title");
		String regfirstName = datamap.get("FirstName");
		String reglastName = datamap.get("LastName");

		// registerpage.getEmailField().sendKeys(randomEmailAddress);
		registerpage.getPhoneNumber().sendKeys(regPhNo);
		registerpage.getpassword().sendKeys(regCreatePassword);
		registerpage.gettitle().sendKeys(regtitle);
		registerpage.getfirstName().sendKeys(regfirstName);
		registerpage.getlastName().sendKeys(reglastName);

	}

	@Then("^User click on Create Account$")
	public void user_click_on_Create_Account() throws InterruptedException {
		RegisterPage registerpage = new RegisterPage(driver);
		registerpage.clickCreateAccount();
//		    	Thread.sleep(20000);
//		    	registerpage.clickOtpSubmitButton();
	}

	@Then("^User should get validation messages for fields$")
	public void user_should_get_validation_messages_for_fields() {

		RegisterPage registepage = new RegisterPage(driver);
		boolean ststus = registepage.verifyerrormessage();
		Assert.assertTrue(ststus);

	}

	@When("^User enter the registered EmailId or PhoneNumber as (.+) and click continue button$")
	public void user_enter_the_registered_emailid_or_phonenumber_as_and_click_continue1(String loginid) {
		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);
		lr.enterLoginId(loginid);
	}

	@Then("^User should be able to go to login page$")
	public void user_should_be_able_to_go_to_login_page_and_login() {
		LoginPage loginpage = new LoginPage(driver);

		boolean status = loginpage.verifyLoginPage();

		Assert.assertTrue(status);
	}

	@When("^User enter invalid Email or PhoneNumber as (.+) and click continue$")
	public void user_enter_invalid_emailid_or_phonenumber_as_and_click_continue1(String registerid) {

		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);
		lr.enterinvalidLoginId(registerid);
	}

	@Then("^User should receive error message$")
	public void user_should_receive_error_message() {

		String actualstatus;
		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);
		String errormsg = lr.getErrorMessage();
		if (errormsg.contains("INVALID")) {
			actualstatus = "true";

		} else {
			actualstatus = "false";

		}
		Assert.assertEquals("true", actualstatus);

	}

}
