package Stepdefinitions;

import java.util.ArrayList;
import java.util.Properties;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import BaseClass.Base;
import PageObjects.ForgotPasswordPage;
import PageObjects.HomePage;
import PageObjects.LoginOrRegisterPage;
import PageObjects.LoginPage;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ForgotPassword extends Base {

	WebDriver driver;
	// Properties prop;

	@Before("@Forgotpassword")
	public void setup() {

		loadProjectDataProperties();
		this.driver = initializeBrowser(prop.getProperty("browser"));

	}

	@After("@Forgotpassword")
	public void tearDown() {

		driver.quit();

	}

	@Given("^User visit the yatra website$")
	public void user_visit_the_yatra_website() {

		driver.get(prop.getProperty("url"));
	}

	@And("^User hover on MyAccount and click login button$")
	public void user_hover_on_myaccount_and_click_login() {
		HomePage homePage = new HomePage(driver);
		homePage.selectMyAccountMenu();
		homePage.selectLoginOption();
	}

	@When("^User enter the proper EmailId or Phonenumber and click continue button$")
	public void user_enter_the_proper_emailidphonenumber_and_click_continue_button() {
		String loginid = prop.getProperty("emailorphone");
		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);
		lr.enterLoginId(loginid);
	}

	@Then("^User should be redirected to signin page$")
	public void user_should_be_redirected_to_signin_page() {
		LoginPage loginpage = new LoginPage(driver);

		boolean status = loginpage.verifyLoginPage();

		Assert.assertTrue(status);
	}

	@And("^User click Forgot Passwork link$")
	public void user_click_forgot_passwork_link() throws Throwable {
		ForgotPasswordPage fp = new ForgotPasswordPage(driver);
		fp.clickForgotPassword();
	}

	@Then("^User should be able to reach forgot password page$")
	public void user_should_be_able_to_reach_forgot_password_page() {
		ForgotPasswordPage fp = new ForgotPasswordPage(driver);
		fp.verifyforgotPasswordPage();
	}

	@And("^User enters valid registered email as (.+) for which password should reset$")
	public void user_enters_valid_registered_email_as_for_which_password_should_reset(String emailid) {

		ForgotPasswordPage fp = new ForgotPasswordPage(driver);

		fp.sendemail(emailid);

	}

	@And("^User clicks continue button$")
	public void user_clicks_continue_button() throws Throwable {
		ForgotPasswordPage fp = new ForgotPasswordPage(driver);
		fp.clickcontinuebutton();
	}

	@Then("^User should get an email to the mail and redirect to Mail send success page$")
	public void user_should_get_an_email_to_the_mail_and_redirect_to_mail_send_success_page()
			throws InterruptedException {

		ForgotPasswordPage fp = new ForgotPasswordPage(driver);
		Thread.sleep(10000);
		boolean status = fp.verifyemailsendsuccess();

		Assert.assertTrue(status);
	}

	@Then("^User is able to go click on the link send to the email to reset password$")
	public void user_is_able_to_go_click_on_the_link_send_to_the_email_to_reset_password() throws InterruptedException {
		Thread.sleep(1000);
		String result = check();
		String urlreturn = geturl(result);
		String clicklnk = Keys.chord(Keys.CONTROL, Keys.ENTER);
		WebDriverWait wait = new WebDriverWait(driver, 300);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,'Proceed to login')]")));
		driver.findElement(By.xpath("//button[contains(.,'Proceed to login')]")).sendKeys(clicklnk);

		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1)); // switches to new tab
		driver.get(urlreturn);

	}

	@And("^User enters new password and confirm password$")
	public void user_enters_new_password_and_confirm_password() {
		ForgotPasswordPage fp = new ForgotPasswordPage(driver);
		// String pass = "36472598.AWER";
		String pass = genertePassword();
		System.out.println(pass);
		fp.passPassword(pass);

		updateProjectDataProperties(pass);

	}

	@And("^Click reset password$")
	public void click_reset_password() {

		ForgotPasswordPage fp = new ForgotPasswordPage(driver);
		fp.clickResetPasswordButton();
	}

	@Then("^User redirects to success page$")
	public void use_redirects_to_success_page() throws InterruptedException {
		ForgotPasswordPage fp = new ForgotPasswordPage(driver);
		Thread.sleep(2000);
		fp.verifyresetPasswordsuccess();

	}

	///////////
	@Then("^User clicks Proceed to login$")
	public void user_clicks_proceed_to_login() throws InterruptedException {
		ForgotPasswordPage fp = new ForgotPasswordPage(driver);

		Thread.sleep(3000);
		fp.clickProceedToLogin();
	}

	@Then("^User reaches Login page$")
	public void user_reaches_Login_page() throws InterruptedException {
		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);
		Thread.sleep(2000);
		boolean status = lr.verifyloginregisterPage();

		Assert.assertTrue(status);
	}

	@When("^User enter the registered EmailId as (.+) and click continue button$")
	public void user_enter_the_registered_emailid_as_and_click_continue_button(String emailid)
			throws InterruptedException {

		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);
		Thread.sleep(1000);
		lr.enterLoginId(emailid);
	}

	@And("^User should be able to enter password$")
	public void user_should_be_able_to_enter_password() {
		loadProjectDataProperties();
		String newPassword = prop.getProperty("password");
		System.out.println(newPassword);
		LoginPage loginpage = new LoginPage(driver);
		loginpage.login(newPassword);
	}

	@And("^click Login Button$")
	public void click_login() throws InterruptedException {
		LoginPage loginpage = new LoginPage(driver);
		Thread.sleep(1000);
		loginpage.clickLoginButton();
	}

	@Then("^User should redirect to Home Page with diplayed name in header section$")
	public void user_should_redirect_to_home_page_with_diplayed_firstname_in_header_section()
			throws InterruptedException {
		HomePage homePage = new HomePage(driver);
		Thread.sleep(1000);
		boolean val = homePage.verifyCorrectUserName();
		Assert.assertTrue(val);
	}

	// Scenario2
	@And("^User click Back button$")
	public void user_click_back_button() throws InterruptedException {
		ForgotPasswordPage fp = new ForgotPasswordPage(driver);
		Thread.sleep(2000);
		fp.clickbackArrow();
	}

	@Then("^User should be able to return to Home Page$")
	public void user_should_be_able_to_return_to_home_page() throws InterruptedException {
		HomePage homepage = new HomePage(driver);
		Thread.sleep(1000);
		homepage.verifyhomePage();
	}

}
