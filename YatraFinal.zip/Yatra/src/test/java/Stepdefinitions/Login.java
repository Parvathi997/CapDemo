package Stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import BaseClass.Base;
import PageObjects.HomePage;
import PageObjects.LoginOrRegisterPage;
import PageObjects.LoginPage;
import PageObjects.RegisterPage;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Login extends Base {
	WebDriver driver;

	@Before("@Login")
	public void setup() {

		loadProjectDataProperties();
		this.driver = initializeBrowser(prop.getProperty("browser"));

	}

	@After("@Login")
	public void tearDown() {

		driver.quit();

	}

//Scenario1
	@Given("^User visit the Yatra website$")
	public void user_visit_the_yatra_website() {

		driver.get(prop.getProperty("url"));

	}

	@And("^User hover on MyAccount and click Login$")
	public void user_hover_on_myaccount_and_click_login() {
		HomePage homePage = new HomePage(driver);
		homePage.selectMyAccountMenu();
		homePage.selectLoginOption();

	}

	@When("^User enter the registered EmailId/Phonenumber as (.+) and click continue button$")
	public void user_enter_the_emailidphonenumber_as_and_click_continue_button(String loginid) {
		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);
		lr.enterLoginId(loginid);
	}

	@Then("^User should reach the Signin page$")
	public void user_should_reach_the_signin_page() {

		LoginPage loginpage = new LoginPage(driver);

		boolean status = loginpage.verifyLoginPage();

		Assert.assertTrue(status);

	}

	@And("^User enter the password as (.+)$")
	public void user_enter_the_password_as(String password) {
		LoginPage loginpage = new LoginPage(driver);
		loginpage.login(password);

	}

	@And("^click Login$")
	public void click_login() {
		LoginPage loginpage = new LoginPage(driver);
		loginpage.clickLoginButton();
	}

	@Then("^user should redirect to Home Page with diplayed firstname in header section$")
	public void user_should_redirect_to_home_page_with_diplayed_firstname_in_header_section() throws InterruptedException {
		HomePage homePage = new HomePage(driver);
		Thread.sleep(2000);	
		boolean val = homePage.verifyCorrectUserName();
		Assert.assertTrue(val);
	}

//Scenario2

	@When("^User enter the not registered EmailId as (.+) and click continue button$")
	public void user_enter_the_not_registered_EmailId_as_loginid_and_click_continue_button(String loginid) {
		// Write code here that turns the phrase above into concrete actions
		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);
		lr.enterLoginId(loginid);
	}

	@Then("^User should be redirected to Signup page$")
	public void user_should_be_redirected_to_signup_page() throws InterruptedException {
		RegisterPage registerpage = new RegisterPage(driver);
		
		boolean reg = registerpage.verifyRegisterPage();
		System.out.println(reg);
		Assert.assertTrue(reg);

	}

//Scenario3
	@When("^User enters invalid (.+) and click continue$")
	public void user_enters_invalid_and_click_continue(String loginid) {
		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);
		lr.enterinvalidLoginId(loginid);
	}

	@Then("^User should get proper error message$")
	public void user_should_get_proper_error_message() {
		String actualstatus;
		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);
		String errormsg = lr.getErrorMessage();
		if (errormsg.contains("INVALID")) {
			actualstatus = "true";

		} else {
			actualstatus = "false";

		}
		Assert.assertEquals("true", actualstatus);
	}

//Scenario4
	@When("^User enter registered EmailId or Phonenumber as (.+) and click continue button$")
	public void user_enter_the_registered_emailid_or_phonenumber_as_and_click_continue_button(String loginid) {
		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);
		lr.enterLoginId(loginid);

	}

	@Then("^User should be able to reach the Signin page$")
	public void user_should_be_able_to_reach_the_signin_page() {
		LoginPage loginpage = new LoginPage(driver);

		boolean status = loginpage.verifyLoginPage();

		Assert.assertTrue(status);
	}

	@And("^User should be able to click 'Login as a different user' link and redirect to login page$")
	public void user_should_be_able_to_click_login_as_a_different_user_link_and_redirect_to_login_page() {
		LoginPage loginpage = new LoginPage(driver);
		loginpage.clickLoginAsDifferentUser();
		LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);
		boolean fbbutton = lr.verifyloginregisterPage();
		Assert.assertTrue(fbbutton);

	}


//Scenario5

  @Then("^User enter the registered EmailId or Phonenumber as (.+) and click continue button$"
  ) public void user_enter_the_registered_emailidphonenumber(String loginid) {
  
  LoginOrRegisterPage lr = new LoginOrRegisterPage(driver);
  lr.enterLoginId(loginid);
  
  }
  
  @Then("^User should reach the login page$") public void
  user_should_reach_the_login_page() { LoginPage loginpage = new
  LoginPage(driver);
  
  boolean status = loginpage.verifyLoginPage();
  
  Assert.assertTrue(status);
  
  }
  
  @And("^User enter invalid password as (.+)$") public void
  user_enter_ivalid_password_as(String password) { LoginPage loginpage = new
  LoginPage(driver); loginpage.login(password);
  
  
  }
  
  @And("^click Login button$") public void click_login_button() { LoginPage
  loginpage = new LoginPage(driver); loginpage.clickLoginButton(); }
  
  @Then("^user should get error message$")
  public void user_should_get_error_message() throws InterruptedException 
  { 
  String actualstatus; 
  LoginPage loginpage=new LoginPage(driver); 
  Thread.sleep(10000);
  String errormsg = loginpage.getErrorMessage(); 
  System.out.println("roor"+errormsg);
  if (errormsg.contains("invalid")|| errormsg.contains("wrong")) {
	  actualstatus= "true";
  
  } else { actualstatus = "false";
  
  } Assert.assertEquals("true", actualstatus); }
  
  }
 

	
