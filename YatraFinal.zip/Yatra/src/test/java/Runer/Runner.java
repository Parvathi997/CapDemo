package Runer;

import java.io.File;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features= {"Features\\Login.feature","Features\\Register.feature","Features\\Forgot_Password.feature"},
glue="Stepdefinitions",
plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/html/ExtentReport.html"})
public class Runner {

	
	@AfterClass
	public static void setup()
	{
	Reporter.loadXMLConfig(new File("src\\main\\java\\Rsources\\extent-config.xml"));
	//Reporter.setSystemInfo("Test User", System.getProperty("user.name"));
	Reporter.setSystemInfo("User Name", "Parvathi");
	Reporter.setSystemInfo("Application Name", "Yatra");
	Reporter.setSystemInfo("Operating System Type", System.getProperty("os.name").toString());
	Reporter.setSystemInfo("Environment", "testing");
	Reporter.setTestRunnerOutput("Test Execution Cucumber Report");
	}
}
//D:\Yatra\Yatra\Features
//D:\Yatra\Yatra\src\test\java\Stepdefinitions
//features={"automatedTestingServices.feature", "smoketest.feature"})
//features="Features"