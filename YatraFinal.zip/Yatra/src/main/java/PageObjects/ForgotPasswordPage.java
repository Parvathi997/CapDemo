package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.Base;

public class ForgotPasswordPage extends Base {

WebDriver driver;
	
	public ForgotPasswordPage(WebDriver driver) {
		
		this.driver = driver;
		
		PageFactory.initElements(driver,this);

	}
	@FindBy(xpath = "//a[contains(.,'Forgot Password?')]")
	WebElement forgotpasswordLink;
	
	@FindBy(xpath = "//p[contains(.,\"Forgot Your Yatra Account's Password!\")]")
	WebElement forgotPasswordPageTitle;
	
	@FindBy(className = "back-arrow")
	WebElement backArrow;
	
//	@FindBy(id = "back-arrow")
//	WebElement continuebuttonFG;
	
	@FindBy(xpath = "//p[contains(text(),'Reset password link sent successfully to your Emai')]")
	WebElement rsetpassswordLinkSentSuccess;
	
	
	@FindBy(xpath = "//button[contains(.,'Proceed to login')]")
	WebElement proceedToLogin;
	
	@FindBy(id = "email")
	WebElement emailidtoResetPassword;
	
	@FindBy(id = "continue-btn")
	WebElement contbuttoninfg;
	
	@FindBy(id = "password")
	WebElement password;
	
	@FindBy(id = "confirm-password")
	WebElement confirmpassword;
	
	@FindBy(id = "continue-btn-reset-password")
	WebElement resetPasswordButton;
	@FindBy(xpath = "//p[contains(.,\"Yatra Account's Password Successfully Reset\")]")
	WebElement resetPasswordsuccess;
	
	public void clickProceedToLogin()
	{
		
		proceedToLogin.click();
	}
	
	public void confirmemailsend()
	
	{
		rsetpassswordLinkSentSuccess.isDisplayed();
		//proceedToLogin.isDisplayed();
	}
	
	public void clickbackArrow()
	{
		
		backArrow.click();
	}
	 public void verifyforgotPasswordPage()
	 {
		 forgotPasswordPageTitle.isDisplayed();
	 }
	 
	 public void verifyforgotPasswordLink()
	 {
		 
		 forgotpasswordLink.isDisplayed();
	 }
	 
	 public void clickForgotPassword()
	 {
		 
		 forgotpasswordLink.click();
	 }
	 
	 public void sendemail(String loginid)
	 {
		 emailidtoResetPassword.sendKeys(loginid);
	 }
	 
	 public void clickcontinuebutton()
	 {
		 contbuttoninfg.click();
	 }
	 
	 public boolean verifyemailsendsuccess()
	 {
		 
		return rsetpassswordLinkSentSuccess.isDisplayed();
	 }

	public void passPassword(String pass) {
		// TODO Auto-generated method stub
		password.sendKeys(pass);
		confirmpassword.sendKeys(pass);
	}

	public void clickResetPasswordButton() {
		// TODO Auto-generated method stub
		resetPasswordButton.click();
	}

	public void verifyresetPasswordsuccess() {
		// TODO Auto-generated method stub
		resetPasswordsuccess.isDisplayed();
	}

	public void verifyHomePage() {
		// TODO Auto-generated method stub
		
	}
}
