package PageObjects;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import gherkin.lexer.Id;

public class RegisterPage {
WebDriver driver;
	
	public RegisterPage(WebDriver driver) {
		
		this.driver = driver;
		
		PageFactory.initElements(driver,this);

	}
	@FindBy(id = "signup-email-id")
	WebElement registerEmailId;
	
	@FindBy(id="signup-mobile-number")
	WebElement registerPhoneNumber;
	
	@FindBy(id="isd-selector")
	WebElement isdSelector;
	
	@FindBy(id="signup-password")
	WebElement password;
	
	
	@FindBy(id="signup-user-designation")
	WebElement title;
	
	@FindBy(id="signup-user-first-name")
	WebElement firstName;
	
	@FindBy(id="signup-user-last-name")
	WebElement lastName;
	
	@FindBy(id="signup-password-viewer")
	WebElement passwordViewer;
	
	@FindBy(xpath = "//label[@for='specialPromoNotif']")
	WebElement specialPromNotification;
	
	@FindBy(xpath="//label[@for='whatsAppNotif']")
	WebElement whatsappNotification;
	
	
	@FindBy(id = "signup-form-continue-btn")
	WebElement signUpContinue;
	
	@FindBy(xpath  = "//button[contains(.,'Go To Homepage')]")
	WebElement gotoHomeScreen;
	
	@FindBy(id = "verify-otp")
	WebElement otpSubmit;
	
	@FindBy(id = "resend-email-verification-link")
	WebElement resendEmailVerificationLink;
	
	@FindBy(id="otp-header")
	WebElement otpHeader;
	
	@FindBy(xpath="//button[normalize-space()='Create a New Account']")
	WebElement createnewAccount;
	
	@FindBy(id = "otp-input")
	WebElement otpField;
	
//	@FindBy(className = "//p[@class='fs-14 text-uppercase mb10 label text-red']")
//	WebElement errormsgs;
	
	
	public boolean verifyRegisterPage() throws InterruptedException
	{
		Thread.sleep(2000);
		return whatsappNotification.isDisplayed();
	}
	
	public WebElement getEmailField()
	{
		return registerEmailId;
		
	}
	public WebElement getPhoneNumber()
	{
		return registerPhoneNumber;
		
	}
	public WebElement getpassword()
	{
		return password;
		
	}
	public WebElement gettitle()
	{
		return title;
		
	}
	public WebElement getfirstName()
	{
		return firstName;
		
	}
	public WebElement getlastName()
	{
		return lastName;
		
	}
	
	

	public void clickCreateAccount() throws InterruptedException {
		// TODO Auto-generated method stub
		
		signUpContinue.click();
		
	}
	


	public void clickgotoHomeScreen() throws InterruptedException {
		System.out.println("gotohomescreen");
		Thread.sleep(20000);
		gotoHomeScreen.click();
	}
	
	public void clickOtpSubmitButton() throws InterruptedException
	
	{
		String textr=otpHeader.getText();
		

		
		JavascriptExecutor executor = (JavascriptExecutor)driver; 
		  executor.executeScript("arguments[0].scrollIntoView(true);", otpSubmit);
		  Thread.sleep(20000);
		
		  otpSubmit.click();
		
	}

	public boolean verifyRegistersuccesPage() {
		System.out.println("title"+driver.getTitle());
		 WebDriverWait wait= new WebDriverWait(driver,100); 
		 wait.until(ExpectedConditions.elementToBeClickable(By.id("resend-email-verification-link")));
		 
		return gotoHomeScreen.isDisplayed();
	}
	
	
	public void clickcreateNewAccount() {
		
		
		createnewAccount.click();
	}

	public boolean checkphoneNumberAlresdyRegistered() throws InterruptedException {
		
		//WebDriverWait wait= new WebDriverWait(driver,30);
		  //wait.until(ExpectedConditions.elementToBeClickable(By.id("continue-btn")));
		if(driver.findElement(By.xpath("//button[normalize-space()='Create a New Account']")).isDisplayed())
		{
	      return true;

		}
		else
		{
			return false;
		}

	}
	
	public boolean verifyerrormessage() {

	List<WebElement> errormsgs=driver.findElements(By.xpath("//p[@class='fs-14 text-uppercase mb10 label text-red']"));
	int l=errormsgs.size();
	System.out.println(l);
	if(l>0)
	{
		return true;
	}
	else
		
	{
		return false;
	}
	}
}
