package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import BaseClass.Base;

public class LoginOrRegisterPage {
WebDriver driver;
	LoginPage login=new LoginPage(driver);
	public LoginOrRegisterPage(WebDriver driver) {
		
		this.driver = driver;
		
		PageFactory.initElements(driver,this);

	}
	@FindBy(id = "login-input")
	WebElement LoginId;
	
	@FindBy(id = "login-continue-btn")
	WebElement loginContinueButton;
	
	
	@FindBy(id = "login-error")
	WebElement errorDisplay;
	
	@FindBy(id = "login-title")
	WebElement loginTitle;
	
	@FindBy(id = "fb-login-btn")
	WebElement fbbutton;
	
	public void enterLoginId(String emailorphno) 
	{
		System.out.println("inside enterloginid");
		if (emailorphno.contains("@")) {
			System.out.println("insideif");
			LoginId.sendKeys(emailorphno);
			loginContinueButton.click();
			}
		else
		{
			LoginId.sendKeys(emailorphno);
			loginContinueButton.click();
			   WebDriverWait wait= new WebDriverWait(driver,50); 
			  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[@class='mt15 text-blue text-center fs-12 password-login cur-point']"))); 
			  WebElement loginWithPassword =driver.findElement(By.xpath("//p[@class='mt15 text-blue text-center fs-12 password-login cur-point']"));  
			  JavascriptExecutor executor = (JavascriptExecutor)driver; 
			  executor.executeScript("arguments[0].scrollIntoView(true);", loginWithPassword);
				loginWithPassword.click();
			 
			
		}
		
		
	}
	
	public String getErrorMessage()
	{
		
		return loginTitle.getText();
	}

	public void enterinvalidLoginId(String loginid2) {
		// TODO Auto-generated method stub
		LoginId.sendKeys(loginid2);
		loginContinueButton.click();
		
	}
	
	public boolean verifyloginregisterPage()
	{
		return fbbutton.isDisplayed();
		
	}

	public void enterRegisterId(String loginid2) throws InterruptedException {
		// TODO Auto-generated method stub
		System.out.println("inside enterregisterid");
		if (loginid2.contains("@")) {
			
//			LoginId.sendKeys(loginid2);
//			loginContinueButton.click();
			String randomEmailAddress = null;
	    	String originalEmail = loginid2;
	    	String[] emailParts = originalEmail.split("@");
	    	randomEmailAddress = emailParts[0]+Base.getTimeStamp()+"@"+emailParts[1];
	    	LoginId.sendKeys(randomEmailAddress);
			loginContinueButton.click();
		}
		else
		{
			 RegisterPage registerpage=new RegisterPage(driver);
		    
		    	
		    	registerpage.clickOtpSubmitButton();
			
		}
	}
}
