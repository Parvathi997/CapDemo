package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	WebDriver driver;
	

	public HomePage(WebDriver driver) {

		this.driver = driver;

		PageFactory.initElements(driver, this);

	}

	@FindBy(linkText = "My Account")
	WebElement myAccountDropMenu;

	@FindBy(id = "signInBtn")
	WebElement loginbtn;

	@FindBy(id = "SignUpBtn")
	WebElement registerbtn;

	@FindBy(xpath = "//a[@title='https://www.yatra.com']//i[@class='ico-newHeaderLogo']")
	WebElement logo;

	@FindBy(xpath = "//a[contains(.,'Hi ')]")
	WebElement userNameLabel;


	
	public void selectMyAccountMenu() {
		Actions actions = new Actions(driver);
		actions.moveToElement(myAccountDropMenu).perform();

	}

	public void selectLoginOption() {

		loginbtn.click();

	}

	public void selectRegisterOption() {

		registerbtn.click();

	}

	public void clickLogo() {

		logo.click();
	}

	public boolean verifyCorrectUserName() {
		return userNameLabel.isDisplayed();

	}
	
	public void verifyhomePage()
	{
		myAccountDropMenu.isDisplayed();
	}
}
