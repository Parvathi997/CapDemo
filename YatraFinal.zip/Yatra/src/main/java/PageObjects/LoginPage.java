package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.Base;

public class LoginPage {

WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		
		this.driver = driver;
		
		PageFactory.initElements(driver,this);

	}
	
	
	@FindBy(id = "login-password")
	WebElement loginPassword;
	
	@FindBy(id = "login-submit-btn")
	WebElement loginSubmitButton;
	
	@FindBy(linkText = "Forgot Password?")
	WebElement forgotPassword;
	
	@FindBy(id = "login-as-different-user")
	WebElement loginAsADifferentUser;
	
	@FindBy(id = "login-error")
	WebElement errorDisplay;
	
	@FindBy(id = "login-as-different-user")
	WebElement loginAsDifferentUser;
	
	public void clickLoginAsDifferentUser()
	{
		loginAsDifferentUser.click();
		
	}
	
	public boolean verifyLoginPage() 
	{
		
		return forgotPassword.isDisplayed();
	}
	
	public void login(String SignInPassword)
	{
		
		loginPassword.sendKeys(SignInPassword);
		
		
	}
	
	public String getErrorMessage()
	{
		
		return errorDisplay.getText();
	}
	
	public void clickLoginButton()
	{
		
		loginSubmitButton.click();
	}
	
}
