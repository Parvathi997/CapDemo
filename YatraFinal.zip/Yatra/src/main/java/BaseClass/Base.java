package BaseClass;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Flags.Flag;
import javax.mail.internet.MimeMultipart;
import javax.mail.search.FlagTerm;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.jsoup.Jsoup;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.opera.OperaDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Base {
	WebDriver driver;
	public Properties prop;
	
	public WebDriver initializeBrowser(String browser) {
		
		if(browser.equalsIgnoreCase("chrome")) {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-notifications");
			
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver(options);
			
		}else if(browser.equalsIgnoreCase("firefox")) {
			
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			
		}else if(browser.equalsIgnoreCase("ie")) {
			
			WebDriverManager.iedriver().setup();
			driver = new InternetExplorerDriver();
			
		}else if(browser.equalsIgnoreCase("edge")) {
			
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			
		}else if(browser.equalsIgnoreCase("opera")) {
			
			WebDriverManager.operadriver().setup();
			driver = new OperaDriver();
			
		}
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		return driver;
		
	}
	
	
	public void loadProjectDataProperties() {
		
		prop = new Properties();
		
		String projectPath = System.getProperty("user.dir");
		
		File file = new File(projectPath+"\\src\\main\\java\\Rsources\\data.properties");
		
		try {
		
		FileInputStream fis = new FileInputStream(file);
		
		prop.load(fis);
		
		}catch(Throwable t) {
			
			System.out.println(t.getMessage());
			
		}
		
	}
public void updateProjectDataProperties(String password) {
		
		prop = new Properties();
		
		String projectPath = System.getProperty("user.dir");
		try {
		
		PropertiesConfiguration config = new PropertiesConfiguration(projectPath+"\\src\\main\\java\\Rsources\\data.properties");
		config.setProperty("password", password);
		config.save();
		System.out.println("Config Property Successfully Updated..");
		}catch (Exception e) {
			// TODO: handle exception
		}
	}

	public static String getTimeStamp() {
		Date date = new Date();
		String timeStampModified = date.toString().replaceAll(" ","_").replaceAll(":","_");
		return timeStampModified;
	}
	
	public static String check() {
		String result = "";
		String host = "imap.gmail.com";
		String mailStoreType = "imap";
		String user = "captest56@gmail.com";
		String password = "36472598";

		try {
			
			// create properties
			Properties properties = new Properties();

			properties.put("mail.imap.host", host);
			properties.put("mail.imap.port", "993");
			properties.put("mail.imap.starttls.enable", "true");
			properties.put("mail.imap.ssl.trust", host);

			Session emailSession = Session.getDefaultInstance(properties);

			// create the imap store object and connect to the imap server
			Store store = emailSession.getStore("imaps");

			store.connect(host, user, password);

			// create the inbox object and open it
			Folder inbox = store.getFolder("Inbox");
			inbox.open(Folder.READ_WRITE);

			// retrieve the messages from the folder in an array and print it
			Message[] messages = inbox.search(new FlagTerm(new Flags(Flag.SEEN), false));
			System.out.println("messages.length---" + messages.length);

			for (int i = 0, n = messages.length; i < n; i++) {
				Message message = messages[i];
				message.setFlag(Flag.SEEN, true);
				//System.out.println("---------------------------------");
				//System.out.println("Email Number " + (i + 1));
				String subject=message.getSubject();
				//System.out.println(subject);//welcome to myntra
				//System.out.println("From: " + message.getFrom()[0]);//donotreply.myntra.com
				//System.out.println("Text: " + message.getContent().toString());
				//System.out.println("messgae"+message);
				if (message.isMimeType("text/plain")) {
			        result = message.getContent().toString();
			    } else if (message.isMimeType("multipart/*")) {
			        MimeMultipart mimeMultipart = (MimeMultipart) message.getContent();
			        result = getTextFromMimeMultipart(mimeMultipart);
			    }
				//System.out.println("Text1: " + result);
			}

			inbox.close(false);
			store.close();

		} catch (NoSuchProviderException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	private static String getTextFromMimeMultipart(
	        MimeMultipart mimeMultipart)  throws MessagingException, IOException{
	    String result = "";
	    int count = mimeMultipart.getCount();
	    for (int i = 0; i < count; i++) {
	        BodyPart bodyPart = mimeMultipart.getBodyPart(i);
	        if (bodyPart.isMimeType("text/plain")) {
	            result = result + "\n" + bodyPart.getContent();
	            break; // without break same text appears twice in my tests
	        } else if (bodyPart.isMimeType("text/html")) {
	            String html = (String) bodyPart.getContent();
	            result = result + "\n" + Jsoup.parse(html).text();
	        } else if (bodyPart.getContent() instanceof MimeMultipart){
	            result = result + getTextFromMimeMultipart((MimeMultipart)bodyPart.getContent());
	        }
	    }
	    return result;

}
	public String geturl(String result)
	{
	int n=0;
	String[] arr = result.split("\s", 0);  

	      for(int i=0;i<arr.length;i++)
	      {
	      if(arr[i].contains("http")) {
	     n=i;
	      }
	       
	      }
	     return arr[n];

	}
	
	public String genertePassword()
	{
		System.out.println("here");
		int len=8;
		
		
			String chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi"
	          +"jklmnopqrstuvwxyz!@#$%&";
			Random rnd = new Random();
			StringBuilder sb = new StringBuilder(len);
			for (int i = 0; i < len; i++)
				sb.append(chars.charAt(rnd.nextInt(chars.length())));
			sb.append(12);
			System.out.println("@@@@@@@@@@"+sb.toString());
			return sb.toString();
		
	}
}

